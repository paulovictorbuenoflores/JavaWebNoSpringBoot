package com.primeiroProjetoSpringBoot.myfirstprojet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyfirstprojetApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyfirstprojetApplication.class, args);
	}

}
